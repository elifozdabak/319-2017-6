package constants;

import java.awt.Color;

/**
 *
 * @Author: Ahmet Batu Orhan
 * CS319 Term Project (Summer 2017)
 */


public class UIColors 
{
    public final static Color LIGHTBLUE = new Color(16, 96, 160);
    public final static Color NIGHTBLUE = new Color(1, 46, 83);    
}
